//
//  ViewController.swift
//  DottedViewExample
//
//  Created by Rashid on 11/11/2020.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet private weak var dottedView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad() 
        dottedView.addDashBorder(color: .red, cornerRadius: 10)
    }


}

 
extension UIView {
    func addDashBorder(color:UIColor, cornerRadius: CGFloat) {
        let color = color.cgColor

        let shapeLayer:CAShapeLayer = CAShapeLayer()

        let frameSize = self.frame.size
        let shapeRect = CGRect(x: 0, y: 0, width: frameSize.width, height: frameSize.height)

        shapeLayer.bounds = shapeRect
        shapeLayer.name = "DashBorder"
        shapeLayer.position = CGPoint(x: frameSize.width/2, y: frameSize.height/2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color
        shapeLayer.lineWidth = 1.5
        shapeLayer.lineJoin = .round
        shapeLayer.lineDashPattern = [2,4]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: cornerRadius).cgPath

        self.layer.masksToBounds = false

        self.layer.addSublayer(shapeLayer)
    }
}
